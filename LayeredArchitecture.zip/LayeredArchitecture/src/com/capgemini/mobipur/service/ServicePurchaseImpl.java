package com.capgemini.mobipur.service;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.dao.IPurchaseDetailsDAO;
import com.capgemini.mobipur.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		  
		IPurchaseDetailsDAO purchaseDetailsDAO  = new PurchaseDetailsDAOImpl();
		
		boolean isItInserted = purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
		
		return isItInserted;
	}

}
