package com.capgemini.mobipur.pi;

import java.time.LocalDate;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.IServicePurchaseMobile;
import com.capgemini.mobipur.service.ServicePurchaseImpl;

public class MobilePurchaseMain {

	public static void main(String[] args) {
		 
		PurchaseDetailsBean pdb = new PurchaseDetailsBean(1,"abc","abc@ab.com","9995178956",LocalDate.now(),1002);
		
		IServicePurchaseMobile isp = new ServicePurchaseImpl();
		
		try{
			boolean isInserted = isp.insertPurchaseDetails(pdb);
			
			if(isInserted){
				System.out.println("Record inserted Successfully");
			}
		}catch(MobilePurchaseException mpe){
			System.out.println(mpe.getMessage());
			
		}

	}

}
