package com.capgemini.mobipur.bean;

import java.time.LocalDate;

public class PurchaseDetailsBean {
   private int purchaseId;
   private String name;
   private String mailId;
   private String phoneNo;
   private LocalDate purchaseDate;
   private int mobileId;

   
   public PurchaseDetailsBean() {                           //Default Constructor
	super();
}

                                                                      //Parametrized Constructor
public PurchaseDetailsBean(String name, String mailId,        
		String phoneNo, int mobileId) {
	super();
	this.name = name;
	this.mailId = mailId;
	this.phoneNo = phoneNo;
	this.mobileId = mobileId;
}

//GETTER AND SETTER

public int getPurchaseId() {
	return purchaseId;
}

public void setPurchaseId(int purchaseId) {
	this.purchaseId = purchaseId;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getMailId() {
	return mailId;
}

public void setMailId(String mailId) {
	this.mailId = mailId;
}

public String getPhoneNo() {
	return phoneNo;
}

public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;

}

public int getMobileId() {
	return mobileId;
}

public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}

//TO STRING

@Override
public String toString() {
	return "PurchaseDetailsBean [purchaseId=" + purchaseId + ", name=" + name
			+ ", mailId=" + mailId + ", phoneNo=" + phoneNo + ", purchaseDate="
			+ purchaseDate + ", mobileId=" + mobileId + "]";
}


   
   
   
   
}
